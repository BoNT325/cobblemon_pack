tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> ignite","color":"red"}]

# ignite
playsound minecraft:item.firecharge.use ambient @a[distance=..8] ~ ~ ~ .5 .5
particle minecraft:campfire_cosy_smoke ~ ~-.4 ~ .3 .1 .3 0 10
particle minecraft:large_smoke ~ ~-.2 ~ .2 .3 .2 0 20

# summon
execute align xyz positioned ~.5 ~.5 ~.5 run summon minecraft:marker ~ ~ ~ {Tags:["fkcpf.campfire","fkcpf.campfire.firsttick","fkcpf.campfire.init"],CustomName:'{"text":"Campfire","italic":false}'}
scoreboard players operation @e[type=minecraft:marker,tag=fkcpf.campfire.init,distance=...5] fkcpf.life = #60 fktool
execute as @e[type=minecraft:marker,tag=fkcpf.campfire.init,distance=...5] at @s align y positioned ~ ~1 ~ if predicate fkcpf:outdoor_detect_1.20 run tag @s add fkcpf.campfire.outdoor
tag @e[type=minecraft:marker,tag=fkcpf.campfire.init,distance=...5] remove fkcpf.campfire.init

# schedule loops
schedule function fkcpf:systems/life/loop 3s append
schedule function fkcpf:schedules/weather 10s append

# kill
kill @e[type=minecraft:item,distance=..1,nbt={Age:0s,Item:{id:"minecraft:charcoal",count:2}}]
kill @e[type=minecraft:item,distance=..1,nbt={Age:0s,Item:{id:"minecraft:soul_soil",count:1}}]
kill @s
