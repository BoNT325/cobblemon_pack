# kill lifeless firecamps
execute as @e[type=minecraft:marker,tag=fkcpf.campfire] unless score @s fkcpf.life matches 1.. at @s run function fkcpf:systems/life/die

# clean scoreboards
execute unless entity @e[type=minecraft:marker,tag=fkcpf.campfire,limit=1] run scoreboard players reset * fkcpf.life
execute unless entity @e[type=minecraft:marker,tag=fkcpf.campfire,limit=1] run scoreboard players reset * fkcpf.lvl
execute unless entity @e[type=minecraft:marker,tag=fkcpf.campfire,scores={fkcpf.life.offset=1..},limit=1] run scoreboard players reset * fkcpf.life.offset


schedule function fkcpf:schedules/cleaner 3600s
