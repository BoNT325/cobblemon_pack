# scores
scoreboard objectives add fktool dummy

# fkversion
scoreboard players set #FktoolVersion fktool 12100
execute store success score #tmp fktool run function fkcpftool:fkversion
scoreboard players reset #FktoolVersion fktool
execute if score #tmp fktool matches 0 run return run tellraw @a[tag=fkdev] [{"text":"[fktool] exit: error during update","color":"red"}]

# init
function fkcpftool:utils/set_constants
function fkcpftool:difficulty/get
function fkcpftool:mcv/get
function fkcpftool:rng/get
function fkcpftool:warnings/get

# modules
#function fkcpftool:systime/get
