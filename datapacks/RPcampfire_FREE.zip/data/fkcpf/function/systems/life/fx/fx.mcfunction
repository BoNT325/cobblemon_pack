execute if block ~ ~ ~ minecraft:campfire run return run function fkcpf:systems/life/fx/flame
execute if block ~ ~ ~ minecraft:soul_campfire run return run function fkcpf:systems/life/fx/soul
