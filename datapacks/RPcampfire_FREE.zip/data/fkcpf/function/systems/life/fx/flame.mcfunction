# fx
execute if score @s fkcpf.lvl matches 0.. run particle minecraft:flame ~ ~ ~ .3 .5 .3 .01 5
execute if score @s fkcpf.lvl matches 0..1 positioned ~ ~-.4 ~ run particle minecraft:large_smoke ~ ~ ~ .2 .2 .2 .01 10
execute if score @s fkcpf.lvl matches 2..3 positioned ~ ~.8 ~ run particle minecraft:flame ~ ~ ~ .3 1 .3 .01 10
execute if score @s fkcpf.lvl matches 2..3 positioned ~ ~.8 ~ run particle minecraft:dust_color_transition{from_color:[1.0f,0.5f,0.0f],scale:2.0f,to_color:[0.7f,0.15f,0.0f]} ~ ~ ~ .2 1 .2 .01 5
execute if score @s fkcpf.lvl matches 4.. positioned ~ ~2 ~ run particle minecraft:flame ~ ~ ~ .1 1.5 .1 .01 10
execute if score @s fkcpf.lvl matches 4.. positioned ~ ~2 ~ run particle minecraft:dust_color_transition{from_color:[1.0f,0.5f,0.0f],scale:2.0f,to_color:[0.7f,0.15f,0.0f]} ~ ~ ~ .1 1.5 .1 .01 5
