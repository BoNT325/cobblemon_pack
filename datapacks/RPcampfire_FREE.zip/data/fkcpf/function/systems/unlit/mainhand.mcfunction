schedule function fkcpf:systems/unlit/revoke 1t

item modify entity @s weapon.mainhand fkcpf:unlit_campfires
