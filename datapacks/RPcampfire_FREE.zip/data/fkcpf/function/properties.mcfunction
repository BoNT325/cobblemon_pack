### RP Campfire Datapack
###
### Developped by FunkyToc
### With love
### And a big amount of time


## ITEMS

# Unlit automaticly your campfires items in your hands
# Default: 1
# 0: disabled
# 1: enabled
execute unless score AutoUnlitItem fkcpf.options matches 0.. run scoreboard players set AutoUnlitItem fkcpf.options 1

# Lit automaticly your campfires with a log (without flint and steel)
# Default: 0
# 0: disabled
# 1: enabled
execute unless score AutoLitCampfire fkcpf.options matches 0.. run scoreboard players set AutoLitCampfire fkcpf.options 0

# Unlit automaticly diying campfires
# Default: 1
# 0: disabled
# 1: enabled
execute unless score AutoUnlitCampfire fkcpf.options matches 0.. run scoreboard players set AutoUnlitCampfire fkcpf.options 1


## CAMPFIRE

# Duration added per log thrown into a campfire (second)
# Default: 60
# 10: 10s added
# 30: 30s added
execute unless score LogDuration fkcpf.options matches 0.. run scoreboard players set LogDuration fkcpf.options 60

# Rain reduce campfire duration IF not covered (%)
# Default: 30
# Range: 0 - 1000
#  30: +30% duration loss
# 100: +100% duration loss
execute unless score RainInfluencePercent fkcpf.options matches 0.. run scoreboard players set RainInfluencePercent fkcpf.options 30

# Thunder reduce campfire duration IF not covered (%)
# Default: 50
# Range: 0 - 1000
#  50: +50% duration loss
# 100: +100% duration loss
execute unless score ThunderInfluencePercent fkcpf.options matches 0.. run scoreboard players set ThunderInfluencePercent fkcpf.options 50

# Charcoal drop cooldown on ignited campfires (second)
# Default: 60
# Range: 1 - 999
# 30: drop every 30s after the initial ignite
# 60: drop every 60s after the initial ignite
execute unless score CoalPulseSec fkcpf.options matches 0.. run scoreboard players set CoalPulseSec fkcpf.options 60

# Regeneration pulse cooldown on lit campfire (second)
# Default: 15
# 15: regen every 15s
# 30: regen every 30s
execute unless score RegenPulseSec fkcpf.options matches 0.. run scoreboard players set RegenPulseSec fkcpf.options 15

# Regeneration affects nearby players
# Default: 1
# 0: disabled
# 1: enabled
execute unless score RegenPlayers fkcpf.options matches 0.. run scoreboard players set RegenPlayers fkcpf.options 1

# Regeneration affects nearby pets
# Default: 1
# 0: disabled
# 1: enabled
execute unless score RegenPets fkcpf.options matches 0.. run scoreboard players set RegenPets fkcpf.options 1

# Regeneration heart particles on heal
# Default: 1
# 0: disabled
# 1: enabled
execute unless score RegenParticles fkcpf.options matches 0.. run scoreboard players set RegenParticles fkcpf.options 1

# Freeze close monsters near campfires level max (slowness effect 4)
# Default: 1
# 0: disabled
# 1: enabled
execute unless score FreezeMonsters fkcpf.options matches 0.. run scoreboard players set FreezeMonsters fkcpf.options 1

# Show custom particles on campfire regen
# Default: 1
# 0: disabled
# 1: enabled
execute unless score AddParticles fkcpf.options matches 0.. run scoreboard players set AddParticles fkcpf.options 1


## COOKING

# Cooking buff system
# Default: 1
# 0: disabled
# 1: enabled
execute unless score CookingBuff fkcpf.options matches 0.. run scoreboard players set CookingBuff fkcpf.options 1

# Max percentage cooking speed buff (at firecamp level 3) (sensivity 5%)
# Default: 30
# 30: +30% cooking speed
# 100: +100% cooking speed (= x2)
execute unless score MaxCookingBuff fkcpf.options matches 0.. run scoreboard players set MaxCookingBuff fkcpf.options 30
