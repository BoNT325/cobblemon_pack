scoreboard players set AutoUnlitItem fkcpf.options 1
scoreboard players set AutoLitCampfire fkcpf.options 0
scoreboard players set AutoUnlitCampfire fkcpf.options 1
scoreboard players set LogDuration fkcpf.options 60
scoreboard players set RainInfluencePercent fkcpf.options 30
scoreboard players set ThunderInfluencePercent fkcpf.options 50
scoreboard players set CoalPulseSec fkcpf.options 60
scoreboard players set RegenPulseSec fkcpf.options 15
scoreboard players set RegenPlayers fkcpf.options 1
scoreboard players set RegenPets fkcpf.options 1
scoreboard players set RegenParticles fkcpf.options 1
scoreboard players set FreezeMonsters fkcpf.options 1
scoreboard players set AddParticles fkcpf.options 1
scoreboard players set CookingBuff fkcpf.options 1
scoreboard players set MaxCookingBuff fkcpf.options 30

tellraw @s ["",{"text":"[RPcampfire] ","bold":true,"color":"gold"},{"text":"Options have been reset","color":"red"}]
