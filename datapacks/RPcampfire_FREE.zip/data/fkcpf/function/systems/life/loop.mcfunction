# do
execute as @e[type=minecraft:marker,tag=fkcpf.campfire,scores={fkcpf.life=..-1}] at @s run function fkcpf:systems/life/die
execute as @e[type=minecraft:marker,tag=fkcpf.campfire,scores={fkcpf.life=0..}] at @s run function fkcpf:systems/life/live

# timer
scoreboard players remove @e[type=minecraft:marker,tag=fkcpf.campfire,scores={fkcpf.life=0..}] fkcpf.life 1

# loop
execute if entity @e[type=minecraft:marker,tag=fkcpf.campfire,limit=1] run schedule function fkcpf:systems/life/loop 1s replace
