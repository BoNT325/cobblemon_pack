tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> regen_players","color":"red"}]

# fx
execute if score @s fkcpf.lvl matches 5.. at @a[distance=..10,gamemode=!spectator] positioned ~ ~.5 ~ run particle minecraft:heart ~ ~ ~ .1 .1 .1 0 1
execute if score @s fkcpf.lvl matches 004 at @a[distance=..07,gamemode=!spectator] positioned ~ ~.5 ~ run particle minecraft:heart ~ ~ ~ .1 .1 .1 0 1
execute if score @s fkcpf.lvl matches 003 at @a[distance=..06,gamemode=!spectator] positioned ~ ~.5 ~ run particle minecraft:heart ~ ~ ~ .1 .1 .1 0 1
execute if score @s fkcpf.lvl matches 002 at @a[distance=..05,gamemode=!spectator] positioned ~ ~.5 ~ run particle minecraft:heart ~ ~ ~ .1 .1 .1 0 1
execute if score @s fkcpf.lvl matches ..1 at @a[distance=..04,gamemode=!spectator] positioned ~ ~.5 ~ run particle minecraft:heart ~ ~ ~ .1 .1 .1 0 1

# regen players
execute if score @s fkcpf.lvl matches 5.. run return run effect give @a[distance=..10,gamemode=!spectator] minecraft:regeneration 1 2 false
execute if score @s fkcpf.lvl matches 004 run return run effect give @a[distance=..07,gamemode=!spectator] minecraft:regeneration 1 2 false
execute if score @s fkcpf.lvl matches 003 run return run effect give @a[distance=..06,gamemode=!spectator] minecraft:regeneration 1 2 false
execute if score @s fkcpf.lvl matches 002 run return run effect give @a[distance=..05,gamemode=!spectator] minecraft:regeneration 1 2 false
execute if score @s fkcpf.lvl matches ..1 run return run effect give @a[distance=..04,gamemode=!spectator] minecraft:regeneration 1 2 false
