schedule function fkcpf:systems/unlit/revoke 1t

item modify entity @s weapon.offhand fkcpf:unlit_campfires
