execute store success score #CookSlot0 fkcpf.life run data get block ~ ~ ~ Items[0].Slot
execute if score #CookSlot0 fkcpf.life matches 1 run function fkcpf:systems/cook/cook
