scoreboard objectives add fkcpf.options dummy {"text":"RP Campfire Options","color":"#eb8c34"}
scoreboard objectives add fkcpf.life dummy {"text":"Campfire Lifetime","color":"#eb8c34"}
scoreboard objectives add fkcpf.life.offset dummy {"text":"fkcpf.life.offset","color":"#eb8c34"}
scoreboard objectives add fkcpf.lvl dummy {"text":"Campfire Level","color":"#eb8c34"}

function fkcpf:properties
function fkcpf:schedules/list

tellraw @a ["",{"text":"[RPcampfire] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Enabled. "},{"text":"See all projects on "},{"text":"PMC","color":"#3366cc","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/funkytoc/submissions/"}},{"text":" or "},{"text":"Modrinth","color":"#1bd96a","clickEvent":{"action":"open_url","value":"https://modrinth.com/user/FunkyToc"}},{"text":"!"}]
execute if score McVersion fktool matches ..12006 run tellraw @a ["",{"text":"[RPcampfire] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Version 1.20.6 or inferior detected !","color":"red"}]
execute if score McVersion fktool matches ..12006 run tellraw @a ["",{"text":"[RPcampfire] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"This datapack needs 1.21+","color":"red"}]
execute if score McVersion fktool matches 12100.. run tellraw @a ["",{"text":"[RPcampfire] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Modify Options "},{"text":"[click here]","bold":true,"color":"aqua","clickEvent":{"action":"suggest_command","value":"/function fkcpf:options/get"}}]
execute if score McVersion fktool matches 12100.. run tellraw @a ["",{"text":"[RPcampfire] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"You're playing the FREE version, get the customizable version "},{"text":"[becoming a Patreon]","bold":true,"color":"aqua","clickEvent":{"action":"open_url","value":"https://www.patreon.com/funkytoc"}}]
tellraw @a[tag=fkdev] [{"text":"Loaded with McVersion -> ","color":"red"},{"score":{"name":"McVersion","objective":"fktool"},"color":"gray"}]
