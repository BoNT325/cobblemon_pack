kill @e[type=minecraft:marker,tag=fkcpf.campfire]

scoreboard objectives remove fkcpf.options
scoreboard objectives remove fkcpf.life
scoreboard objectives remove fkcpf.life.offset
scoreboard objectives remove fkcpf.lvl

give @s minecraft:command_block[custom_name='{"color":"#AF91FF","italic":false,"text":"RP Campfire: Entity Remover"}',lore=['{"color":"white","italic":false,"text":"Hide this command_block at your spawn for fiew days."}','{"color":"white","italic":false,"text":"It will kill loaded remaining campfires when they are loaded."}','{"color":"red","italic":false,"text":"Change into \\"Repeat & Always Active\\" mode, or build a redstone loop."}'],block_entity_data={id:"minecraft:repeating_command_block",TrackOutput:1b,powered:1b,auto:0b,CustomName:'{"color":"#AF91FF","italic":false,"text":"RP Campfire Entity Remover"}',Command:"kill @e[type=minecraft:marker,tag=fkcpf.campfire]"}]

function fkcpftool:uninstall

datapack disable "file/RPcampfire.zip"
datapack disable "file/RPcampfire_FREE.zip"

tellraw @s ["",{"text":"[RPcampfire] ","bold":true,"color":"gold"},{"text":"Uninstalled","color":"red"}]
