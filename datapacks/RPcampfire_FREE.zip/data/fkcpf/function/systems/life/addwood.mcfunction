tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> add_wood","color":"red"}]

# fx
execute if block ~ ~ ~ minecraft:campfire run particle minecraft:flame ~ ~-.2 ~ .2 .3 .2 0 10
execute if block ~ ~ ~ minecraft:soul_campfire run particle minecraft:soul_fire_flame ~ ~-.2 ~ .2 .3 .2 0 10
playsound minecraft:item.firecharge.use ambient @a[distance=..8] ~ ~ ~ .2 .5
particle minecraft:large_smoke ~ ~-.2 ~ .2 .3 .2 0 10

# add duration
scoreboard players operation @e[type=minecraft:marker,tag=fkcpf.campfire,distance=...5,limit=1] fkcpf.life += #60 fktool

# check outdoor
execute as @e[type=minecraft:marker,tag=fkcpf.campfire,distance=...5,limit=1] at @s align y positioned ~ ~1 ~ if predicate fkcpf:outdoor_detect_1.20 run tag @s add fkcpf.campfire.outdoor
execute as @e[type=minecraft:marker,tag=fkcpf.campfire.outdoor,distance=...5,limit=1] at @s align y positioned ~ ~1 ~ unless predicate fkcpf:outdoor_detect_1.20 run tag @s remove fkcpf.campfire.outdoor

# schedule life loop
schedule function fkcpf:systems/life/loop 3s append

# reset
kill @s
