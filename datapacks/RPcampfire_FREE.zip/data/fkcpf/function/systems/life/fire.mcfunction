# choose behavior
execute if entity @e[type=minecraft:marker,tag=fkcpf.campfire,distance=...5,limit=1] run function fkcpf:systems/life/addwood
execute unless entity @e[type=minecraft:marker,tag=fkcpf.campfire,distance=...5,limit=1] if block ~ ~ ~ #fkcpf:campfires_1.20[lit=true] run function fkcpf:systems/life/ignite
