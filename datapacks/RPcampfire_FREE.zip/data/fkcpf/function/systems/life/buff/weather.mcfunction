tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> weather_reduction","color":"red"}]

# init
execute unless score @s fkcpf.life.offset matches 0.. run scoreboard players set @s fkcpf.life.offset 0

# thunder
scoreboard players set #thunder fkcpf.life.offset 10
scoreboard players operation #thunder fkcpf.life.offset *= #50 fktool
scoreboard players operation #thunder fkcpf.life.offset /= #100 fktool
execute if predicate fkcpftool:weather/thunder run return run scoreboard players operation @s fkcpf.life.offset += #thunder fkcpf.life.offset

# rain
scoreboard players set #rain fkcpf.life.offset 10
scoreboard players operation #rain fkcpf.life.offset *= #30 fktool
scoreboard players operation #rain fkcpf.life.offset /= #100 fktool
execute if predicate fkcpftool:weather/rainy run return run scoreboard players operation @s fkcpf.life.offset += #rain fkcpf.life.offset
