# get data
scoreboard players reset #CookSlot0 fkcpf.life
scoreboard players reset #CookSlot1 fkcpf.life
scoreboard players reset #CookSlot2 fkcpf.life
scoreboard players reset #CookSlot3 fkcpf.life

execute store success score #CookSlot0 fkcpf.life run data get block ~ ~ ~ Items[0].Slot
execute store success score #CookSlot1 fkcpf.life run data get block ~ ~ ~ Items[1].Slot
execute store success score #CookSlot2 fkcpf.life run data get block ~ ~ ~ Items[2].Slot
execute store success score #CookSlot3 fkcpf.life run data get block ~ ~ ~ Items[3].Slot

execute if score #CookSlot0 fkcpf.life matches 1 store result score #CookTime0 fkcpf.life run data get block ~ ~ ~ CookingTimes[0]
execute if score #CookSlot1 fkcpf.life matches 1 store result score #CookTime1 fkcpf.life run data get block ~ ~ ~ CookingTimes[1]
execute if score #CookSlot2 fkcpf.life matches 1 store result score #CookTime2 fkcpf.life run data get block ~ ~ ~ CookingTimes[2]
execute if score #CookSlot3 fkcpf.life matches 1 store result score #CookTime3 fkcpf.life run data get block ~ ~ ~ CookingTimes[3]

# set buff
scoreboard players operation #CookingBuffPercent fkcpf.life = #30 fktool
execute if score @s fkcpf.lvl matches 2..3 run scoreboard players operation #CookingBuffPercent fkcpf.life /= #2 fktool
execute if score @s fkcpf.lvl matches 0..1 run scoreboard players operation #CookingBuffPercent fkcpf.life /= #4 fktool
scoreboard players operation #CookingBuffTick fkcpf.life = #20 fktool
scoreboard players operation #CookingBuffTick fkcpf.life *= #CookingBuffPercent fkcpf.life
scoreboard players operation #CookingBuffTick fkcpf.life /= #100 fktool

# add buff
execute if score #CookSlot0 fkcpf.life matches 1 run scoreboard players operation #CookTime0 fkcpf.life += #CookingBuffTick fkcpf.life
execute if score #CookSlot1 fkcpf.life matches 1 run scoreboard players operation #CookTime1 fkcpf.life += #CookingBuffTick fkcpf.life
execute if score #CookSlot2 fkcpf.life matches 1 run scoreboard players operation #CookTime2 fkcpf.life += #CookingBuffTick fkcpf.life
execute if score #CookSlot3 fkcpf.life matches 1 run scoreboard players operation #CookTime3 fkcpf.life += #CookingBuffTick fkcpf.life

# storage
execute if score #CookSlot0 fkcpf.life matches 1 store result storage fkcpf Cook.Slot0 int 1 run scoreboard players get #CookTime0 fkcpf.life
execute if score #CookSlot1 fkcpf.life matches 1 store result storage fkcpf Cook.Slot1 int 1 run scoreboard players get #CookTime1 fkcpf.life
execute if score #CookSlot2 fkcpf.life matches 1 store result storage fkcpf Cook.Slot2 int 1 run scoreboard players get #CookTime2 fkcpf.life
execute if score #CookSlot3 fkcpf.life matches 1 store result storage fkcpf Cook.Slot3 int 1 run scoreboard players get #CookTime3 fkcpf.life

# blockdata
execute if score #CookSlot0 fkcpf.life matches 1 run data modify block ~ ~ ~ CookingTimes[0] set from storage minecraft:fkcpf Cook.Slot0
execute if score #CookSlot1 fkcpf.life matches 1 run data modify block ~ ~ ~ CookingTimes[1] set from storage minecraft:fkcpf Cook.Slot1
execute if score #CookSlot2 fkcpf.life matches 1 run data modify block ~ ~ ~ CookingTimes[2] set from storage minecraft:fkcpf Cook.Slot2
execute if score #CookSlot3 fkcpf.life matches 1 run data modify block ~ ~ ~ CookingTimes[3] set from storage minecraft:fkcpf Cook.Slot3
