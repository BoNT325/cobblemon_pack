# log on campfire
execute at @a[gamemode=!spectator] as @e[type=minecraft:item,distance=..6,predicate=fkcpf:ignite_materials_1.20] at @s if block ~ ~ ~ #fkcpf:campfires_1.20 run function fkcpf:systems/life/fire

# restart life loop
execute if entity @e[type=minecraft:marker,tag=fkcpf.campfire,limit=1] run schedule function fkcpf:systems/life/loop 3s append

# loop
schedule function fkcpf:schedules/ignite 3s
