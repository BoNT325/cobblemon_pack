tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> die","color":"red"}]

# extinguish
execute if block ~ ~ ~ minecraft:campfire[lit=true] run setblock ~ ~ ~ minecraft:campfire[lit=false] destroy
execute if block ~ ~ ~ minecraft:soul_campfire[lit=true] run setblock ~ ~ ~ minecraft:soul_campfire[lit=false] destroy
kill @e[type=item,distance=..1,nbt={Age:0s,Item:{id:"minecraft:charcoal",count:2}}]
kill @e[type=item,distance=..1,nbt={Age:0s,Item:{id:"minecraft:soul_soil",count:1}}]

# fx
playsound minecraft:block.lava.extinguish ambient @a[distance=..8] ~ ~ ~ .5 .7
execute if block ~ ~ ~ minecraft:campfire run particle minecraft:campfire_signal_smoke ~ ~-.2 ~ .3 .1 .3 0 10
execute if block ~ ~ ~ minecraft:soul_campfire run particle minecraft:soul ~ ~ ~ .4 .4 .4 .02 20
particle minecraft:campfire_cosy_smoke ~ ~-.4 ~ .3 .1 .3 0 10
particle minecraft:large_smoke ~ ~-.2 ~ .2 .3 .2 0 20

# reset
scoreboard players reset @s fkcpf.life
scoreboard players reset @s fkcpf.life.offset
kill @s
