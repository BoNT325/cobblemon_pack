tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> regen_pets","color":"red"}]

# fx
execute if score @s fkcpf.lvl matches 5.. as @e[type=#fkcpf:pets,distance=..16] at @s anchored eyes positioned ^ ^-.2 ^ run particle minecraft:heart ~ ~ ~ .3 .3 .3 0 1
execute if score @s fkcpf.lvl matches 004 as @e[type=#fkcpf:pets,distance=..12] at @s anchored eyes positioned ^ ^-.2 ^ run particle minecraft:heart ~ ~ ~ .3 .3 .3 0 1
execute if score @s fkcpf.lvl matches 003 as @e[type=#fkcpf:pets,distance=..10] at @s anchored eyes positioned ^ ^-.2 ^ run particle minecraft:heart ~ ~ ~ .3 .3 .3 0 1
execute if score @s fkcpf.lvl matches 002 as @e[type=#fkcpf:pets,distance=..08] at @s anchored eyes positioned ^ ^-.2 ^ run particle minecraft:heart ~ ~ ~ .3 .3 .3 0 1
execute if score @s fkcpf.lvl matches ..1 as @e[type=#fkcpf:pets,distance=..06] at @s anchored eyes positioned ^ ^-.2 ^ run particle minecraft:heart ~ ~ ~ .3 .3 .3 0 1

# regen pets
execute if score @s fkcpf.lvl matches 5.. run return run effect give @e[type=#fkcpf:pets,distance=..16] minecraft:regeneration 1 2 true
execute if score @s fkcpf.lvl matches 004 run return run effect give @e[type=#fkcpf:pets,distance=..12] minecraft:regeneration 1 2 true
execute if score @s fkcpf.lvl matches 003 run return run effect give @e[type=#fkcpf:pets,distance=..10] minecraft:regeneration 1 2 true
execute if score @s fkcpf.lvl matches 002 run return run effect give @e[type=#fkcpf:pets,distance=..08] minecraft:regeneration 1 2 true
execute if score @s fkcpf.lvl matches ..1 run return run effect give @e[type=#fkcpf:pets,distance=..06] minecraft:regeneration 1 2 true
