# cancels
execute if block ~ ~ ~ #fkcpftool:airs run return run function fkcpf:systems/life/die
execute if block ~ ~ ~ #fkcpf:campfires_1.20[lit=false] run return run function fkcpf:systems/life/die
execute if score @s fkcpf.life <= @s fkcpf.life.offset run return run function fkcpf:systems/life/die

# set level
scoreboard players set @s fkcpf.lvl 0
scoreboard players operation @s fkcpf.lvl = @s fkcpf.life
scoreboard players operation @s fkcpf.lvl /= #60 fktool

# fx
function fkcpf:systems/life/fx/fx

# speedup cooking
function fkcpf:systems/cook/check

# fear monsters
function fkcpf:systems/life/buff/fear_monsters

# drop coal
scoreboard players operation #tmp fkcpf.life = @s fkcpf.life
scoreboard players operation #tmp fkcpf.life %= #60 fktool
execute if score #tmp fkcpf.life matches 0 unless entity @s[tag=fkcpf.campfire.firsttick] run function fkcpf:systems/life/buff/drop_coal

# regen
scoreboard players operation #tmp fkcpf.life = @s fkcpf.life
scoreboard players operation #tmp fkcpf.life %= #15 fktool
execute if score #tmp fkcpf.life matches 0 unless entity @s[tag=fkcpf.campfire.firsttick] run function fkcpf:systems/life/buff/regen_players
execute if score #tmp fkcpf.life matches 0 unless entity @s[tag=fkcpf.campfire.firsttick] run function fkcpf:systems/life/buff/regen_pets

# start weather loop
execute if entity @s[tag=fkcpf.campfire.outdoor] unless predicate fkcpftool:weather/sunny unless biome ~ ~ ~ #fkcpf:no_rain run schedule function fkcpf:schedules/weather 10s append

# resets
tag @s[tag=fkcpf.campfire.firsttick] remove fkcpf.campfire.firsttick
