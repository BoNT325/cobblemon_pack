advancement revoke @a only fkcpf:campfire_mainhand
advancement revoke @a only fkcpf:campfire_offhand
