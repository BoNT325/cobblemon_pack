tellraw @a[tag=fkdev] [{"selector":"@s","color":"red"},{"text":" -> drop_coal","color":"red"}]

# bonus chance
execute if score @s fkcpf.lvl matches 5.. if predicate fkcpftool:rng/05 run return run summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:2}}
execute if score @s fkcpf.lvl matches 004 if predicate fkcpftool:rng/04 run return run summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:2}}
execute if score @s fkcpf.lvl matches 003 if predicate fkcpftool:rng/03 run return run summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:2}}
execute if score @s fkcpf.lvl matches 002 if predicate fkcpftool:rng/02 run return run summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:2}}
execute if score @s fkcpf.lvl matches 001 if predicate fkcpftool:rng/01 run return run summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:2}}

# 100%
summon minecraft:item ~ ~ ~ {PickupDelay:60,Motion:[0f,.4f,0f],Item:{id:"minecraft:charcoal",count:1}}
