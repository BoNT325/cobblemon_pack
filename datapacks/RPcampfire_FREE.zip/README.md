# RP Campfire
A simple and light Minecraft datapack to add custom mecanisms with campfires. 
Regeneration, recipes, cooking speed up, monster debuff, auto unlit and flame duration manager.

# Requires
- Minecraft 1.21+

# Use
1. Download the package
2. Copy/paste the entire "RPcampfire/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Author
- Name: FunkyToc 
- Website: https://funkytoc.fr
- PMC: https://www.planetminecraft.com/member/funkytoc/
- Modrinth: https://modrinth.com/user/FunkyToc

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks
My Patreons that buy me coffe every days.
My community wich reminds me that I'm lazy.
Minecraft community in general, that gives meaning to this project.
