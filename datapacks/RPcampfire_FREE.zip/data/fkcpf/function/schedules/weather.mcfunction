# weather
execute unless predicate fkcpftool:weather/sunny as @e[tag=fkcpf.campfire.outdoor] at @s unless biome ~ ~ ~ #fkcpf:no_rain run function fkcpf:systems/life/buff/weather

# loop
execute unless predicate fkcpftool:weather/sunny if entity @e[tag=fkcpf.campfire.outdoor,limit=1] run schedule function fkcpf:schedules/weather 10s replace
