execute if score @s fkcpf.lvl matches 000 run return fail
execute if score @s fkcpf.lvl matches 001 run return run effect give @e[type=#fkcpf:fear_campfire,distance=..07,limit=5,sort=nearest] minecraft:slowness 2 2 true
execute if score @s fkcpf.lvl matches 002 run return run effect give @e[type=#fkcpf:fear_campfire,distance=..08,limit=5,sort=nearest] minecraft:slowness 2 3 true
execute if score @s fkcpf.lvl matches 003 run return run effect give @e[type=#fkcpf:fear_campfire,distance=..09,limit=5,sort=nearest] minecraft:slowness 2 4 true
execute if score @s fkcpf.lvl matches 4.. run return run effect give @e[type=#fkcpf:fear_campfire,distance=..10,limit=5,sort=nearest] minecraft:slowness 2 5 true
